library(tidyverse)
library(scales)

# Export/copy your original World Bank FDI CSV into data/fdi.csv.
# Expected columns include Country.Code and X2000, X2001, etc.
fdi <- read_csv("data/fdi.csv", show_col_types = FALSE)

fdi_clean <- fdi %>%
filter(Country.Code %in% c("ARG", "BRA", "CHL", "MEX"))
fdi_clean <- fdi_clean %>%
pivot_longer(
cols = starts_with("X20"),
names_to = "Year",
values_to = "FDI"
) %>%
mutate(
Year = as.numeric(str_remove(Year, "X")),
FDI = as.numeric(FDI)
) %>%
filter(Year >= 2000, Year <= 2025)
ggplot(fdi_clean,
aes(x = Year, y = FDI, colour = Country.Code)) +
geom_line(linewidth = 1.2) +
scale_colour_manual(
values = c(
"ARG" = "#0072B2",
"BRA" = "#009E73",
"CHL" = "#E69F00",
"MEX" = "#CC79A7"
),
labels = c(
"ARG" = "Argentina",
"BRA" = "Brazil",
"CHL" = "Chile",
"MEX" = "Mexico"
)
) +
scale_x_continuous(
breaks = c(seq(2000, 2020, by = 5), 2025)
) +
labs(
title = "Foreign direct investment in Latin America",
subtitle = "Net FDI inflows (% of GDP), 2000–2025",
x = "Year",
y = "FDI inflows (% of GDP)",
colour = "Country",
caption = "Source: World Bank"
) +
theme_minimal() +
theme(
plot.title = element_text(size = 16, face = "bold"),
panel.grid.minor = element_blank(),
legend.position = "bottom"
)
fdi_clean %>%
group_by(Country.Code) %>%
summarise(
mean_fdi = mean(FDI, na.rm = TRUE),
median_fdi = median(FDI, na.rm = TRUE),
.groups = "drop"
)
fdi_clean %>%
filter(!is.na(FDI)) %>%
group_by(Year) %>%
filter(n_distinct(Country.Code) == 4) %>%
slice_min(FDI, n = 1, with_ties = FALSE) %>%
ungroup() %>%
count(Country.Code)
