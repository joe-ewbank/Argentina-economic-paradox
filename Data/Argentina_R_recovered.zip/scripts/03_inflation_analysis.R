library(tidyverse)
library(scales)

# This section uses the original wide-format IMF dataset.
# Expected: first column containing country names and year columns (2000 etc.).
inflation <- read_csv("data/inflation.csv", show_col_types = FALSE)

inflation_clean <- inflation %>%
# Rename the first column to Country
rename(Country = 1) %>%
# Convert all year columns into rows
pivot_longer(
cols = matches("^(19|20)[0-9]{2}$"),
names_to = "Year",
values_to = "Inflation",
values_transform = list(Inflation = as.character)
) %>%
# Convert to numeric values
mutate(
Year = as.numeric(Year),
Inflation = as.numeric(Inflation)
) %>%
# Keep the countries and years we want
filter(
Country %in% c("Argentina", "Brazil", "Chile", "Uruguay"),
Year >= 2000,
Year <= 2025
)
names(inflation_clean)
unique(inflation_clean$Country)
inflation_clean %>%
group_by(Country) %>%
summarise(
observations = sum(!is.na(Inflation)),
first_year = min(Year[!is.na(Inflation)], na.rm = TRUE),
last_year = max(Year[!is.na(Inflation)], na.rm = TRUE)

# Highlight Argentina; preserve gaps where the source has missing values.
ggplot(inflation_clean,
aes(x = Year, y = Inflation,
group = Country)) +
# Other countries in grey
geom_line(
data = inflation_clean %>%
filter(Country != "Argentina"),
colour = "grey65",
linewidth = 0.8,
alpha = 0.7
) +
# Argentina highlighted
geom_line(
data = inflation_clean %>%
filter(Country == "Argentina"),
colour = "#0072B2",
linewidth = 1.4
) +
# Highlight the 2024 peak
geom_point(
data = inflation_clean %>%
filter(Country == "Argentina", Year == 2024),
colour = "#0072B2",
size = 2.8
) +
# Label the peak
annotate(
"text",
x = 2023.5,
y = 225,
label = "2024 inflation peak (219.9%)",
hjust = 1,
size = 3.5,
colour = "#0072B2"
) +
scale_x_continuous(
breaks = seq(2000, 2025, by = 5)
) +
scale_y_continuous(
breaks = seq(0, 250, by = 50),
labels = label_percent(scale = 1)
) +
coord_cartesian(
xlim = c(2000, 2025),
ylim = c(0, 240)
) +
labs(
title = "Argentina's inflation problem",
subtitle = "Annual consumer price inflation, 2000–2025",
x = NULL,
y = "Inflation (%)",
caption = "Source: IMF. Grey lines: Brazil, Chile and Uruguay."
) +
theme_minimal(base_size = 12) +
theme(
plot.title = element_text(
size = 17, face = "bold"
),
plot.subtitle = element_text(size = 11),
panel.grid.minor = element_blank(),
panel.grid.major.x = element_blank(),
legend.position = "none",
axis.title.y = element_text(size = 11)
